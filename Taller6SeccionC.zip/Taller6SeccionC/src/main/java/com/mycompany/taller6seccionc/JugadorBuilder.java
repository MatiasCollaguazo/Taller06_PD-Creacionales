package com.mycompany.taller6seccionc;
/**
 *
 * @author Grupo#2
 */
public class JugadorBuilder implements EntidadBuilder{

    @Override
    public void buildNombre(String nombre) {
        
    }

    @Override
    public void buildAccion(Accion accion) {
        
    }
    
}
