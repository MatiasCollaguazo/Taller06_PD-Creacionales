package com.mycompany.taller6seccionc;

/**
 *
 * @author Grupo#2
 */
public class Objeto {
    private float peso;
    private String tipo;
}
