package com.mycompany.taller6seccionc;

/**
 *
 * @author CltControl
 */
public class EntidadDirector {
    private EntidadBuilder builder;
}
