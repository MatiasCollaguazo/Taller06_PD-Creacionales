package com.mycompany.taller6seccionc;

/**
 *
 * @author Grupo#2
 */
public interface EntidadBuilder {
    void buildNombre(String nombre);
    void buildAccion(Accion accion);
}
