package com.mycompany.taller6seccionc;

/**
 *
 * @author CltControl
 */
public class Enemigo {
    private String tipo;
    private float poder;
}
