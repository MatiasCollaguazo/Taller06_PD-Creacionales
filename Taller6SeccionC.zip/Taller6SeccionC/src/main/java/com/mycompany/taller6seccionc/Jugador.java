package com.mycompany.taller6seccionc;

/**
 *
 * @author CltControl
 */
public class Jugador {
    private float vida;
    private float fuerza;
}
