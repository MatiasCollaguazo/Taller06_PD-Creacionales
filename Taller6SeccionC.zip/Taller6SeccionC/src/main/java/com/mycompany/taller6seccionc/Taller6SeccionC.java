package com.mycompany.taller6seccionc;

/**
 *
 * @author Grupo#2
 */
public class Taller6SeccionC {

    public static void main(String[] args) {
        //System.out.println("Hello World!");
    }
}
