package com.mycompany.taller6seccionc;

/**
 *
 * @author Grupo#2
 */
public class Accion {
    String sprite; //La ruta del .jpg/.png asociado a la acción
}
